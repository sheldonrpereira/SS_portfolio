#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct ESTAB {
    char csname[10];
    char extsym[10];
    int address;
    int length;
};

struct ESTAB es[100];
int estab_count = 0;

void print_memory(FILE *fp, int start_addr, int length, char *object_code) {
    int addr = start_addr;
    int code;
    char byte[3];
    byte[2] = '\0';
    for (int i = 0; i < length * 2; i += 2) {
        strncpy(byte, &object_code[i], 2); 
        sscanf(byte, "%X", &code);        
        fprintf(fp, "%04X   %02X\n", addr++, code);
    }
}

int main() {
    FILE *fp1, *fp2;
    char input[10], input_file[20], obj_code[100];
    int csaddr, add, len, cslen, mem_addr, obj_len;

    printf("Enter input file name: ");
    scanf("%s", input_file);

    fp1 = fopen(input_file, "r");
    if (fp1 == NULL) {
        printf("Error: Cannot open input file.\n");
        return 1;
    }

    fp2 = fopen("output.dat", "w");
    if (fp2 == NULL) {
        printf("Error: Cannot create output file.\n");
        return 1;
    }

    printf("Assume starting address from OS: 5000H\n");
    csaddr = 0x5000; 

    fprintf(fp2, "CSNAME\tEXTSYM\tADDRESS\tLENGTH\n");

    while (fscanf(fp1, "%s", input) != EOF) {
        if (strcmp(input, "H") == 0) {
            
            fscanf(fp1, "%s %x %x", input, &add, &len);
            strcpy(es[estab_count].csname, input);
            strcpy(es[estab_count].extsym, "***");
            es[estab_count].address = csaddr;
            es[estab_count].length = len;
            fprintf(fp2, "%s\t%s\t%X\t%X\n", es[estab_count].csname, es[estab_count].extsym, es[estab_count].address, es[estab_count].length);
            estab_count++;
        } else if (strcmp(input, "D") == 0) {
            
            while (1) {
                fscanf(fp1, "%s", input);
                if (strcmp(input, "R") == 0 || strcmp(input, "T") == 0 || strcmp(input, "END") == 0) {
                    break; 
                }
                strcpy(es[estab_count].csname, "***");
                strcpy(es[estab_count].extsym, input);
                fscanf(fp1, "%x", &add);
                es[estab_count].address = add + csaddr;
                es[estab_count].length = 0;
                fprintf(fp2, "%s\t%s\t%X\t%X\n", es[estab_count].csname, es[estab_count].extsym, es[estab_count].address, es[estab_count].length);
                estab_count++;
            }
        } else if (strcmp(input, "T") == 0) {
        
            fscanf(fp1, "%x %x %s", &mem_addr, &obj_len, obj_code);
            mem_addr += csaddr; 
            fprintf(fp2, "\nMemory Contents:\nADDR   OBJECT CODE\n");
            print_memory(fp2, mem_addr, obj_len, obj_code);
        } else if (strcmp(input, "END") == 0) {
            csaddr += len; 
        }
    }

    fclose(fp1);
    fclose(fp2);

    printf("Processing complete. Output written to output.dat.\n");
    return 0;
}
