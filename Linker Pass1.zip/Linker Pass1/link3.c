#include <stdio.h>
#include <conio.h>
#include <string.h>
#define MAX 30

struct estab {
    char csname[10];
    char extsym[10];
    int address;   
    int length;    
} es[MAX];

int csname_exists(struct estab es[], int count, char *name) {
    for (int i = 0; i < count; i++) {
        if (strcmp(es[i].csname, name) == 0) {
            return 1; 
        }
    }
    return 0; 
}
int symname_exists(struct estab es[], int count, char *name) {
    for (int i = 0; i < count; i++) {
        if (strcmp(es[i].extsym, name) == 0) {
            return 1; 
        }
    }
    return 0; 
}
void main() {
    char input[10], name[10], symbol[10];
    int count = 0, progaddr, csaddr, add, len;
    FILE *fp1, *fp2;

    fp1 = fopen("link.dat", "r");
    fp2 = fopen("load.dat", "w");

    if (fp1 == NULL || fp2 == NULL) {
        printf("Error opening file.\n");
        return;
    }

    printf("Enter the location where the program has to be loaded (hexadecimal): ");
    scanf("%x", &progaddr); 
    
    csaddr = progaddr;
    fprintf(fp2, "CS_NAME\tEXT_SYM_NAME\tADDRESS\tLENGTH\n");
    fprintf(fp2, "--------------------------------------\n");

    fscanf(fp1, "%s", input);
    
    while (strcmp(input, "END") != 0) {
        if (strcmp(input, "H") == 0) { 
            fscanf(fp1, "%s", name); 
            
            if (csname_exists(es, count, name)) {
                printf("Error: Duplicate control section name '%s' found. Aborting.\n", name);
                fclose(fp1);
                fclose(fp2);
                return;
            }

            strcpy(es[count].csname, name);
            strcpy(es[count].extsym, "***");
            fscanf(fp1, "%x", &add); 
            es[count].address = add + csaddr; 
            fscanf(fp1, "%x", &len);  
            es[count].length = len;
            fprintf(fp2, "%s\t%s\t\t\t\t%X\t%X\n", es[count].csname, es[count].extsym, es[count].address, es[count].length);
            count++;
        }
        else if (strcmp(input, "D") == 0) { 
            fscanf(fp1, "%s", input);  
            while (strcmp(input, "R") != 0) {
                strcpy(es[count].csname, "***");
                strcpy(es[count].extsym, input);
                if (symname_exists(es, count, input)) {
                printf("Error: Duplicate control section name '%s' found. Aborting.\n", name);
                fclose(fp1);
                fclose(fp2);
                return;
               }
                fscanf(fp1, "%x", &add);  
                es[count].address = add + csaddr;  
                es[count].length = 0;
                fprintf(fp2, "%s\t\t%s\t\t\t%X\t%X\n", es[count].csname, es[count].extsym, es[count].address, es[count].length);
                count++;
                fscanf(fp1, "%s", input);
            }
            csaddr = csaddr + len; 
        }
        else if (strcmp(input, "T") == 0) { 
            while (strcmp(input, "E") != 0)
                fscanf(fp1, "%s", input);
                  
        }
        fscanf(fp1, "%s", input);  
    }

    fprintf(fp2, "--------------------------------------\n");
    fclose(fp1);
    fclose(fp2);
    printf("FINISHED\n");
    getch();
}



/*
assume that the linking loader gets a start addrress as 5000H from operating sysytem .generate the estab and the memory structure (show the contents of memory address wise as shown below
)
addr   object code
5000   00
5001   00
5002   14*/