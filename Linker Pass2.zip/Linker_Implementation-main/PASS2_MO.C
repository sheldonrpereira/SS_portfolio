#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct exttable {
  char cextsym[20], extsym[20];
  int address, length;
} estab[20];

struct objectcode {
  char code[15];
  int add;
} obcode[500];

int main() {
  char temp[10];
  FILE *fp1, *fp2, *fp3;
  int i, j, x, y, pstart, exeloc, start, textloc, loc, textlen, length;
  int num = 0, inc = 0, count = 0, n = 0;
  char input[10];

  fp1 = fopen("INPUT.DAT", "r");
  fp2 = fopen("ESTAB1.DAT", "r");
  fp3 = fopen("BEFORE_MODIFICATION.DAT", "w");

  // Load external symbol table
  while (!feof(fp2)) {
    fscanf(fp2, "%s %s %x %x", estab[num].cextsym, estab[num].extsym, &estab[num].address, &estab[num].length);
    num++;
  }
  fclose(fp2);

  exeloc = estab[0].address;
  loc = exeloc;
  start = loc;

  // Process the input file
  while (!feof(fp1)) {
    fscanf(fp1, "%s", input);

    if (strcmp(input, "H") == 0) {
      fscanf(fp1, "%s", input);
      for (i = 0; i < num; i++) {
        if (strcmp(input, estab[i].cextsym) == 0) {
          pstart = estab[i].address;
          break;
        }
      }

      while (strcmp(input, "T") != 0) {
        fscanf(fp1, "%s", input);
      }
    }

    do {
      if (strcmp(input, "T") == 0) {
        fscanf(fp1, "%x", &textloc);
        textloc += pstart;

        for (i = 0; i < (textloc - loc); i++) {
          strcpy(obcode[inc].code, "..");
          obcode[inc++].add = start++;
        }

        fscanf(fp1, "%x", &textlen);
        loc = textloc + textlen;
      } else {
        length = strlen(input);
        x = 0;
        for (i = 0; i < length; i++) {
          if (input[i] == '+' || input[i] == '-') i++; // Skip modifiers
          obcode[inc].code[x++] = input[i];
          if (x > 1) {
            obcode[inc++].add = start++;
            x = 0;
          }
        }
      }

      fscanf(fp1, "%s", input);
    } while (strcmp(input, "E") != 0);

    if (strcmp(input, "E") == 0) {
      fscanf(fp1, "%s", input);
    }
  }
  fclose(fp1);

  // Write the object code to the output file
  n = 0;
  count = 0;
  for (i = 0; i < inc; i++) {
    // Skip entries that contain symbolic names or invalid characters
    if (strpbrk(obcode[i].code, "ABCDEFGHIJKLMNOPQRSTUVWXYZ")) {
      continue;
    }
    fprintf(fp3, "%s", obcode[i].code);
    n++;
    if (n > 3) {
      fprintf(fp3, "\t");
      n = 0;
      count++;
    }
    if (count > 3) {
      fprintf(fp3, "\n\n%x\t", obcode[i + 1].add);
      count = 0;
    }
  }
  fclose(fp3);

  // Display the output file contents
  printf("\n\t***** PASS TWO OF A DIRECT-LINKING LOADER *****\n");
  printf("\nThe contents of the output file :\n");
  printf("---------------------------------------------------------------\n");
  printf("Address\t\t\t\tContents\n");
  printf("---------------------------------------------------------------\n");

  fp3 = fopen("BEFORE_MODIFICATION.DAT", "r");
  char ch = fgetc(fp3);
  while (ch != EOF) {
    printf("%c", ch);
    ch = fgetc(fp3);
  }
  fclose(fp3);

  return 0;
}
